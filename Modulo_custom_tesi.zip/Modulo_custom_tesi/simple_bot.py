import telepot

def on_chat_message(msg):
    content_type, chat_type, chat_id = telepot.glance(msg)
    if content_type == 'text':
	name = msg["from"]["first_name"]
        txt = msg['text']
        if '/start' in txt:
            bot.sendMessage(chat_id, 'ciao %s, hai aggiunto un altro paziente alla tua lista in clinical Odoo!'%name)
        elif '/hey' in txt:
            bot.sendMessage(chat_id, 'Heyla')
        #else:
         #   bot.sendMessage(chat_id, 'Mi spiace %s, non capisco'%name)
	else:
	    bot.sendMessage(chat_id, 'ciao %s, hai aggiunto un altro  paziente alla tua lista in clinical Odoo!'%name)
            #bot.sendMessage(chat_id, 'ho ricevuto questo: %s'%txt)
        

TOKEN = '877672196:AAHLefNYnCd8UYqwFQw76Y0oqoAmqkdqYz4'

bot = telepot.Bot(TOKEN)
bot.message_loop(on_chat_message)

print 'Listening ...'

import time
while 1:
    time.sleep(10)

