# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ResPartner(models.Model):
    _inherit = 'res.partner'

    luogo = fields.Many2one('res.city.it.code.distinct', 'Luogo di nascita', track_visibility='onchange')


