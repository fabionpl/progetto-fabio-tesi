# -*- coding: utf-8 -*-
{
    'name': "Luogo_di_nascita",

    'summary': """
        Estensione modulo res_partner con aggiunta di luogo di nascita""",

    'description': """
        Luogo di nascita
    """,

    'author': "Fabio Napoli",
    'website': "http://www.mycompany.com",

    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'partner_contact_personal_information_page'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/res_partner.xml',
        #'views/templates.xml',
    ],

}