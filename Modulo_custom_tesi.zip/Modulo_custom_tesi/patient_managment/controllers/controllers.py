# -*- coding: utf-8 -*-

from odoo import http
from odoo.http import request



class Hello(http.Controller):
    @http.route('/hello', auth='public')
    def index(self, **kw):
        return "Hello, world"       #prova per verificare l'effettiva richiesta

class Custom_module(http.Controller):
    @http.route('/scheda_pazienti', auth='public', website=True)
    def custom_redirect(self):
        return request.redirect('/web?debug#id=&action=347&model=clinical.patient&view_type=form&menu_id=219')



# class Clinical(http.Controller):
#     @http.route('/clinical/clinical/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/clinical/clinical/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('clinical.listing', {
#             'root': '/clinical/clinical',
#             'objects': http.request.env['clinical.clinical'].search([]),
#         })

#     @http.route('/clinical/clinical/objects/<model("clinical.clinical"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('clinical.object', {
#             'object': obj
#         })