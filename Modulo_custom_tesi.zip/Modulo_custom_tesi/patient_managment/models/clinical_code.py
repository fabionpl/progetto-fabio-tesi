from odoo import models, fields, api



class clinicalCode(models.Model):
    _name = 'clinical.code'

    code = fields.Char(string="Codice Fiscale", size=16)
    name = fields.Char(string="Nome")
    surname = fields.Char(string="Cognome")
    data = fields.Date()

