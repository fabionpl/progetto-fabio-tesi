# -*- coding: utf-8 -*-

from . import clinical_patient
from . import clinical_category
from . import clinical_code
#from . import hr_employee
