# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ResPartner(models.Model):
    _inherit = 'res.partner'

    provincia = fields.Many2one('res.country.state', 'Provincia di nascita', track_visibility='onchange')


